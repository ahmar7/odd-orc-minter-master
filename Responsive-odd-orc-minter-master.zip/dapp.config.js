import injected from "@web3-onboard/injected-wallets"

const config = {
    title: 'OddOrcs Dapp'
}

export { config }